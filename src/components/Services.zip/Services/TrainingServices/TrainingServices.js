import React from 'react'

function TrainingServices() {
  return (
    <div>TrainingServices</div>
  )
}

export default TrainingServices