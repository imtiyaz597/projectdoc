import React from 'react'

function AgileApproach() {
  return (
    <div>AgileApproach</div>
  )
}

export default AgileApproach