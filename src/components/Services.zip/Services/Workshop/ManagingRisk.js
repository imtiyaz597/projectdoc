import React from 'react'

function ManagingRisk() {
  return (
    <div>ManagingRisk</div>
  )
}

export default ManagingRisk