import React from 'react'

function Traditional() {
  return (
    <div>Traditional</div>
  )
}

export default Traditional